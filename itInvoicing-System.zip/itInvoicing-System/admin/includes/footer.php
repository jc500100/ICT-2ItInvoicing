  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <a href="index.php" class="scrollto"><strong>ITInvoicing</strong></a> All Rights Reserved.
      </div>
      
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="../assets/plugin/jquery/jquery.min.js"></script>
  <script src="../assets/plugin/jquery/jquery-migrate.min.js"></script>
  <script src="../assets/plugin/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/plugin/easing/easing.min.js"></script>
  <script src="../assets/plugin/superfish/hoverIntent.js"></script>
  <script src="../assets/plugin/superfish/superfish.min.js"></script>
  <script src="../../assets/plugin/wow/wow.min.js"></script>
  <script src="../assets/plugin/owlcarousel/owl.carousel.min.js"></script>
  <script src="../assets/plugin/magnific-popup/magnific-popup.min.js"></script>
  <script src="../assets/plugin/sticky/sticky.js"></script>

  <!-- Template Main Javascript File -->
  <script src="../assets/js/main.js"></script>

</body>
</html>

