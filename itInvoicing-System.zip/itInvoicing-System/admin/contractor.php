<?php
    session_start();
    include("../db/db_connection.php");
    
    if (!isset($_SESSION['fname']) && !isset($_SESSION['lname'])) {
        header('location:admin/admin-login.php');
    }
    
    $contractors = null;
    // getting all inquiries of user
    $query = "SELECT * FROM users WHERE role='contractor'";
    $contractors = mysqli_query($con, $query);
    
    include("includes/header.php");
    if(isset($_GET['id'])){
    	$id=$_GET['id'];
    		 $sql = "delete FROM users where id=$id";
    		
    $q = mysqli_query($con, $sql);

        
    }
    $sql = "SELECT * FROM users where role='contractor'";
    $inquiries = mysqli_query($con, $sql);
?>
 <!--==========================
      Dashboard Section
    ============================-->
    <section id="services">
      <div class="container">
        <div class="section-header">
<!-- <<<<<<< Updated upstream
          <h2>Contractores</h2>
        </div>
            <div class="row">
                <div class="col-md-12 py-5">
                    <table class="table">
                        <thead id="table-header">
                          <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone No</th>
                            <th scope="col">Contractor Type</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($contractors) > 0) {
                                while($row = mysqli_fetch_assoc($contractors)) { ?>
                                    <tr>
                                        <td><?= $row["fname"] ?> <?= $row["lname"] ?></td>
                                        <td><?= $row["email"] ?></td>
                                        <td><?= $row["phno"] ?></td>
                                        <td><?= $row["contractor_type"] ?></td>
                                        <td></td>
                                    </tr>
                            <?php } } ?>
                        </tbody>
                    </table>
                </div>
            </div>
======= -->
          <h2>Contractor</h2>
        
      <a href="add-contractor.php" class="btn btn-success">Add Contractor</a>
        </div>

       
        	<div class="row">
        		<div class="col-md-12 py-5">
        			 <table class="table">
					  <thead id="table-header">
					    <tr>
					      <th scope="col">First Name</th>
					      <th scope="col">Last Name</th>
					      <th scope="col">Email</th>
					      <th scope="col">Phone</th>
					      <th scope="col">Delete</th>
					      

					    </tr>
					  </thead>
					  <tbody>
					     <?php if (mysqli_num_rows($inquiries)) {
                    while($row = mysqli_fetch_assoc($inquiries)) { ?>
                        <tr>
                        <td><?= $row["fname"] ?></td>
                            <td><?= $row["lname"] ?></td>
                            <td><?= $row["email"] ?></td>
                            <td><?= $row["phno"] ?></td>
                            <td><?php echo "<a class='btn btn-danger' href=\"contractor.php?id=".$row['id']."\">Delete</a>" ?></td>
                        </tr>
                <?php } } ?>
					  </tbody>
					</table>
        		</div>

        </div>

      
<!-- >>>>>>> Stashed changes -->
    </section><!-- #services -->


  </main>


<?php
    include("includes/footer.php");
?>

